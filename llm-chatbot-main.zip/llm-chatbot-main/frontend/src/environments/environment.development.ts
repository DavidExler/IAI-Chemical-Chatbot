export const environment = {
    production: false,
    backend_base_url: "http://iai-ml4home028.iai.kit.edu/chatbot-staging",
};
