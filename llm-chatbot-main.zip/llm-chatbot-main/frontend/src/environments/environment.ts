export const environment = {
    production: true,
    backend_base_url: "http://iai-ml4home028.iai.kit.edu/chatbot",
};
